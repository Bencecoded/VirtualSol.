import { BACKEND_URL } from './config.js';

const AXIOM_ORIGIN = 'https://axiom.trade';
const AUTH_KEY = 'vs:auth:v1';
const DEVICE_KEY = 'vs:device:v1';
const SIM_KEY = 'ap:sim';
const GUARD_ID = 'ap-guard';
const pagePorts = new Set();
const popupPorts = new Set();
const quickBuyOpened = new Set();
let refreshInFlight = null;
let pageViewRefresh = null;

function backendBase() {
  if (!BACKEND_URL || BACKEND_URL.includes('SET_WORKER_URL') || !BACKEND_URL.startsWith('https://')) {
    throw new Error('VirtualSol has not been connected to its private backend yet. Build this release with your deployed HTTPS Worker URL.');
  }
  return BACKEND_URL.replace(/\/$/, '');
}
async function getStored(key) {
  const result = await chrome.storage.local.get(key);
  return result[key];
}
async function saveStored(key, value) { await chrome.storage.local.set({ [key]: value }); }
async function removeStored(key) { await chrome.storage.local.remove(key); }
async function getDeviceId() {
  let id = await getStored(DEVICE_KEY);
  if (typeof id !== 'string' || !/^[a-f0-9-]{36}$/i.test(id)) {
    id = crypto.randomUUID();
    await saveStored(DEVICE_KEY, id);
  }
  return id;
}
async function apiPost(path, body, token = null) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${backendBase()}${path}`, { method: 'POST', headers, body: JSON.stringify(body), cache: 'no-store' });
  let data;
  try { data = await response.json(); } catch { throw new Error(`Private backend returned HTTP ${response.status}`); }
  if (!response.ok || data?.ok === false) {
    const error = new Error(data?.error || `Private backend returned HTTP ${response.status}`);
    error.status = response.status;
    error.code = data?.code;
    throw error;
  }
  return data;
}
async function storeAuth(data) {
  await saveStored(AUTH_KEY, {
    accessToken: data.accessToken,
    refreshToken: data.refreshToken,
    accessExpiresAt: data.accessExpiresAt,
    refreshExpiresAt: data.refreshExpiresAt,
    userId: data.userId
  });
}
async function activateLicense(licenseKey) {
  const deviceId = await getDeviceId();
  const result = await apiPost('/v1/auth/activate', { licenseKey, deviceId });
  await storeAuth(result);
  return { authenticated: true, userId: result.userId };
}
async function refreshAuth(force = false) {
  if (refreshInFlight) return refreshInFlight;
  refreshInFlight = (async () => {
    const auth = await getStored(AUTH_KEY);
    if (!auth?.refreshToken) return null;
    if (!force && auth.accessToken && Number(auth.accessExpiresAt) > Date.now() + 45_000) return auth.accessToken;
    try {
      const data = await apiPost('/v1/auth/refresh', { refreshToken: auth.refreshToken });
      await storeAuth(data);
      return data.accessToken;
    } catch (error) {
      if (error.status === 401 || error.status === 403) await removeStored(AUTH_KEY);
      throw error;
    }
  })();
  try { return await refreshInFlight; } finally { refreshInFlight = null; }
}
async function authStatus() {
  try {
    const token = await refreshAuth(true);
    return { authenticated: !!token, backendConfigured: !BACKEND_URL.includes('SET_WORKER_URL') };
  } catch (error) {
    return { authenticated: false, backendConfigured: !BACKEND_URL.includes('SET_WORKER_URL'), error: error.message };
  }
}
async function remoteMessage(message, retry = true) {
  const token = await refreshAuth(false);
  if (!token) throw new Error('Your VirtualSol license is not activated. Enter your license key to continue.');
  const body = { message, axiomTabs: pagePorts.size };
  try {
    return await apiPost('/v1/rpc', body, token);
  } catch (error) {
    if (retry && error.status === 401) {
      const fresh = await refreshAuth(true);
      if (fresh) return remoteMessage(message, false);
    }
    throw error;
  }
}

class LocalSimMode {
  constructor() {
    this.state = { mode: 'UNKNOWN', rev: 0, changedAt: 0 };
    this.busy = false;
    this.onChange = () => {};
  }
  async isRegistered() {
    const scripts = await chrome.scripting.getRegisteredContentScripts({ ids: [GUARD_ID] });
    return scripts.length > 0;
  }
  async register() {
    if (!(await this.isRegistered())) {
      await chrome.scripting.registerContentScripts([{
        id: GUARD_ID, js: ['page.js'], matches: [`${AXIOM_ORIGIN}/*`], runAt: 'document_start',
        world: 'MAIN', allFrames: false, persistAcrossSessions: true
      }]);
    }
  }
  async unregister() {
    if (await this.isRegistered()) await chrome.scripting.unregisterContentScripts({ ids: [GUARD_ID] });
  }
  async init() {
    try {
      const existing = await getStored(SIM_KEY);
      if (existing === undefined) {
        this.state = { mode: 'SIM_ON', rev: 1, changedAt: Date.now() };
        await saveStored(SIM_KEY, this.state);
      } else if (existing && ['SIM_ON','SIM_OFF'].includes(existing.mode) && Number.isSafeInteger(existing.rev)) {
        this.state = { mode: existing.mode, rev: existing.rev, changedAt: Number(existing.changedAt) || 0 };
      } else {
        this.state = { mode: 'UNKNOWN', rev: (Number(existing?.rev) || 0) + 1, changedAt: Date.now(), error: 'Stored paper-trading mode was unreadable' };
      }
    } catch (error) {
      this.state = { mode: 'UNKNOWN', rev: this.state.rev + 1, changedAt: Date.now(), error: `Storage: ${String(error.message).slice(0,80)}` };
    }
    try {
      if (this.state.mode === 'SIM_OFF') await this.unregister();
      else await this.register();
    } catch (error) {
      this.state = { ...this.state, mode: 'UNKNOWN', error: `Guard registration failed: ${String(error.message).slice(0,80)}` };
    }
    this.onChange(this.state);
    return this.state;
  }
  async set(mode, options = {}, beforeOff = async () => {}) {
    if (mode === 'SIM_OFF' && options.confirm !== true) throw Object.assign(new Error('Confirm turning paper trading off'), { code: 'confirm_required' });
    if (this.busy) throw Object.assign(new Error('A paper-trading mode change is already in progress'), { code: 'sim_mode' });
    if (this.state.mode === mode) return this.state;
    this.busy = true;
    const previous = this.state;
    this.state = { mode: 'TRANSITIONING', rev: previous.rev + 1, changedAt: Date.now() };
    this.onChange(this.state);
    try {
      if (mode === 'SIM_OFF') { await beforeOff(); await this.unregister(); }
      else { await this.register(); if (!(await this.isRegistered())) throw new Error('Guard registration could not be confirmed'); }
      this.state = { mode, rev: previous.rev + 2, changedAt: Date.now() };
      await saveStored(SIM_KEY, this.state);
      return this.state;
    } catch (error) {
      try { await this.register(); } catch {}
      this.state = previous.mode === 'SIM_ON'
        ? { ...previous, rev: previous.rev + 2, changedAt: Date.now(), error: String(error.message).slice(0,120) }
        : { mode: 'UNKNOWN', rev: previous.rev + 2, changedAt: Date.now(), error: String(error.message).slice(0,120) };
      await saveStored(SIM_KEY, this.state).catch(() => {});
      throw Object.assign(new Error(`Paper-trading mode not changed: ${String(error.message).slice(0,120)}`), { code: 'sim_mode' });
    } finally {
      this.busy = false;
      this.onChange(this.state);
    }
  }
}
const simMode = new LocalSimMode();
const ready = simMode.init();

function isAxiomSender(sender) {
  try {
    return sender.id === chrome.runtime.id && sender.frameId === 0 && Number.isInteger(sender.tab?.id)
      && new URL(sender.url ?? '').origin === AXIOM_ORIGIN
      && (!sender.tab.url || new URL(sender.tab.url).origin === AXIOM_ORIGIN);
  } catch { return false; }
}
function isExtensionSender(sender) {
  try { return sender.id === chrome.runtime.id && new URL(sender.url ?? '').origin === new URL(chrome.runtime.getURL('/')).origin; }
  catch { return false; }
}
function success(data) { return { ok: true, data }; }
function failure(error) { return { ok: false, error: String(error?.message ?? 'Request failed'), code: error?.code ?? 'error' }; }

async function broadcast() {
  if (pageViewRefresh) return pageViewRefresh;
  pageViewRefresh = (async () => {
    if (!pagePorts.size) return;
    try {
      const { data } = await remoteMessage({ type: 'page:state' });
      for (const port of pagePorts) { try { port.postMessage({ type: 'state', view: data }); } catch { pagePorts.delete(port); } }
      for (const port of popupPorts) { try { port.postMessage({ type: 'state', revision: data.revision, markSeq: data.markSeq }); } catch { popupPorts.delete(port); } }
    } catch { /* The page's existing bridge timeout/lock UX handles temporary network loss. */ }
  })();
  try { await pageViewRefresh; } finally { pageViewRefresh = null; }
}

async function handleMessage(message, sender) {
  await ready;
  if (!message || typeof message !== 'object' || typeof message.type !== 'string') throw new Error('Invalid message');
  if (message.type === 'auth:status') {
    if (!isExtensionSender(sender)) throw new Error('Authentication is only accepted from VirtualSol pages');
    return authStatus();
  }
  if (message.type === 'auth:activate') {
    if (!isExtensionSender(sender)) throw new Error('Authentication is only accepted from VirtualSol pages');
    return activateLicense(String(message.licenseKey ?? '').trim());
  }
  if (message.type === 'auth:logout') {
    if (!isExtensionSender(sender)) throw new Error('Authentication is only accepted from VirtualSol pages');
    const auth = await getStored(AUTH_KEY);
    if (auth?.accessToken) await apiPost('/v1/auth/logout', {}, auth.accessToken).catch(() => {});
    await removeStored(AUTH_KEY);
    return { authenticated: false };
  }
  if (message.type === 'auth:delete-account') {
    if (!isExtensionSender(sender)) throw new Error('Account deletion is only accepted from VirtualSol pages');
    const token = await refreshAuth(false);
    if (!token) throw new Error('Your VirtualSol account is not authenticated.');
    const result = await apiPost('/v1/auth/delete-account', {}, token);
    await removeStored(AUTH_KEY);
    return result;
  }

  if (message.type.startsWith('page:')) {
    if (!isAxiomSender(sender)) throw new Error('Page requests are only accepted from Axiom tabs');
    if (message.type === 'page:openWallets') {
      await chrome.tabs.create({ url: chrome.runtime.getURL('wallets.html'), active: true, openerTabId: sender.tab.id, index: (sender.tab.index ?? 0) + 1, windowId: sender.tab.windowId });
      return { opened: true };
    }
    if (message.type === 'page:afterQuickBuy') {
      const mode = message.mode === 'tab' ? 'tab' : message.mode === 'goto' ? 'goto' : null;
      const orderId = String(message.id ?? '');
      if (!mode || quickBuyOpened.has(orderId)) return { url: null };
      const { data } = await remoteMessage({ type: 'page:afterQuickBuy', id: orderId, mode });
      if (!data?.mint) return { url: null };
      const url = data.pairAddress
        ? `${AXIOM_ORIGIN}/meme/${encodeURIComponent(data.pairAddress)}?chain=sol`
        : `${AXIOM_ORIGIN}/token/${encodeURIComponent(data.mint)}?chain=sol`;
      if (mode === 'tab') {
        quickBuyOpened.add(orderId);
        if (quickBuyOpened.size > 200) quickBuyOpened.delete(quickBuyOpened.values().next().value);
        await chrome.tabs.create({ url, active: true, openerTabId: sender.tab.id, index: (sender.tab.index ?? 0) + 1, windowId: sender.tab.windowId });
      }
      return { url };
    }
    if (message.type === 'page:context') {
      const path = new URL(sender.url).pathname;
      const { data } = await remoteMessage({ ...message, path });
      return data;
    }
    const { data } = await remoteMessage(message);
    await broadcast();
    return data;
  }

  if (message.type.startsWith('popup:')) {
    if (!isExtensionSender(sender)) throw new Error('Account changes are only accepted from VirtualSol pages');
    if (message.type === 'popup:activate') {
      if (!(await refreshAuth(false))) throw new Error('Enter your VirtualSol license key first.');
      if (simMode.state.mode !== 'SIM_ON') await simMode.set('SIM_ON');
      await simMode.register();
      const { data } = await remoteMessage(message);
      const guard = await simMode.isRegistered();
      return { ...data, active: data.active && guard, guard };
    }
    if (message.type === 'popup:status' || message.type === 'popup:view') {
      const { data } = await remoteMessage(message);
      const remoteMode = data?.sim?.mode;
      if (remoteMode === 'SIM_ON' && simMode.state.mode !== 'SIM_ON') await simMode.set('SIM_ON');
      if (remoteMode === 'SIM_OFF' && simMode.state.mode !== 'SIM_OFF') await simMode.set('SIM_OFF', { confirm: true });
      const guard = await simMode.isRegistered();
      if (data?.sim?.mode === 'SIM_ON' && !guard) data.sim = { ...data.sim, mode: 'UNKNOWN', error: 'Local execution guard is not registered' };
      return data;
    }
    if (message.type === 'popup:setSimMode') {
      if (!['SIM_ON','SIM_OFF'].includes(message.mode)) throw new Error('Invalid paper-trading mode');
      if (message.mode === 'SIM_OFF') {
        const { data } = await remoteMessage(message);
        await simMode.set('SIM_OFF', { confirm: message.confirm === true });
        return { ...data, sim: simMode.state };
      }
      await simMode.set('SIM_ON');
      const { data } = await remoteMessage(message);
      return { ...data, sim: simMode.state };
    }
    if (message.type === 'popup:recover') {
      const { data } = await remoteMessage(message);
      for (const port of pagePorts) { try { port.postMessage({ type: 'recover', origin: 'popup' }); } catch { pagePorts.delete(port); } }
      await broadcast();
      return data;
    }
    const { data } = await remoteMessage(message);
    if (!['popup:export','popup:exportPreSolOnly','popup:exportCsv','popup:diagnostics','popup:saveCheckpoint','popup:migrationReport'].includes(message.type)) await broadcast();
    return data;
  }
  throw new Error('Unknown request');
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender).then(data => sendResponse(success(data))).catch(error => sendResponse(failure(error)));
  return true;
});

chrome.runtime.onConnect.addListener(port => {
  if (port.name === 'ap-page' && isAxiomSender(port.sender)) {
    pagePorts.add(port);
    port.onDisconnect.addListener(() => {
      pagePorts.delete(port);
      remoteMessage({ type: 'internal:pageTabs' }).catch(() => {});
    });
    ready.then(async () => {
      try {
        const { data } = await remoteMessage({ type: 'page:hello' });
        port.postMessage({ type: 'state', view: data });
      } catch (error) {
        port.postMessage({ type: 'error', error: String(error.message).slice(0,160) });
      }
    });
  } else if (port.name === 'ap-popup' && isExtensionSender(port.sender)) {
    popupPorts.add(port);
    port.onDisconnect.addListener(() => popupPorts.delete(port));
  } else {
    port.disconnect();
  }
});

chrome.alarms.create('vs:maintenance', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== 'vs:maintenance') return;
  remoteMessage({ type: 'internal:tick' }).catch(() => {});
});
chrome.runtime.onInstalled.addListener(details => {
  if (details.reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') }).catch(() => {});
});
