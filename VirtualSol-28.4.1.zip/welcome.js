import { BACKEND_URL } from './config.js';

const UNIT = 10n ** 24n;
const numPattern = /^([+-]?)(\d+)?(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/;
const el = id => document.getElementById(id);
async function send(message) {
  const response = await chrome.runtime.sendMessage(message);
  if (!response) throw new Error('VirtualSol did not respond. Reload the extension and try again.');
  if (!response.ok) throw Object.assign(new Error(response.error), { code: response.code });
  return response.data;
}
function validStartingAmount() {
  const value = el('start').value.trim().replace(/,/g, '');
  if (!/^\d{1,7}(\.\d{1,9})?$/.test(value)) return null;
  const amount = Number(value);
  return amount > 0 && amount <= 1e6 ? value : null;
}
function fmt(value) {
  if (value == null || value === '') return '—';
  const text = String(value);
  const parsed = Number(text);
  return Number.isFinite(parsed) ? parsed.toLocaleString(undefined, { maximumFractionDigits: 4 }) : text;
}
let authenticated = false;
let hasExistingAccount = false;
let working = false;
function showError(message) {
  el('status').textContent = message;
  el('status').hidden = false;
  el('go').disabled = false;
  el('go').textContent = 'Start trading';
}
function setStep(name, status) { const item = document.querySelector(`#steps li[data-k="${name}"]`); if (item) item.dataset.s = status; }
function updateButton() {
  const licenseNeeded = !authenticated;
  const licenseOk = !licenseNeeded || /^VS-[A-Fa-f0-9]{8}(?:-[A-Fa-f0-9]{8}){3}$/.test(el('license').value.replace(/\s+/g, '').toUpperCase());
  const amountOk = hasExistingAccount || validStartingAmount();
  el('go').disabled = working || !licenseOk || !amountOk;
  if (!working) el('go').textContent = 'Start trading';
}
function setAuthenticated(value) {
  authenticated = value;
  el('license-section').hidden = value;
  el('account-actions').hidden = !value;
}

el('start').addEventListener('input', updateButton);
for (const button of document.querySelectorAll('.quick button')) {
  button.addEventListener('click', () => {
    el('start').value = button.dataset.v;
    for (const item of document.querySelectorAll('.quick button')) item.setAttribute('aria-pressed', String(item === button));
    updateButton();
  });
}
// Keep the browser's caret stable while typing/pasting. Display uppercase with CSS; normalize only at submit.
el('license').addEventListener('input', updateButton);
el('license').addEventListener('keydown', event => { if (event.key === 'Enter' && !el('go').disabled) el('go').click(); });
el('start').addEventListener('keydown', event => { if (event.key === 'Enter' && !el('go').disabled) el('go').click(); });

async function boot() {
  try {
    if (!BACKEND_URL || BACKEND_URL.includes('SET_WORKER_URL')) {
      throw new Error('This extension build has not yet been connected to the private VirtualSol backend.');
    }
    const status = await send({ type: 'auth:status' });
    setAuthenticated(status.authenticated === true);

    if (authenticated) {
      const overview = await send({ type: 'popup:walletsOverview' });
      hasExistingAccount = !overview.pristine;
      if (hasExistingAccount) {
        el('existing-sol').textContent = `${fmt(overview.totals.equitySol)} SOL`;
        el('existing-sub').textContent = `${overview.wallets.length} wallet${overview.wallets.length === 1 ? '' : 's'} · stored in your private account`;
        el('existing').hidden = false;
        el('new').hidden = true;
      } else {
        el('new').hidden = false;
        el('start').focus();
        el('start').select();
      }
    } else {
      el('new').hidden = false;
    }
    updateButton();
  } catch (error) {
    el('new').hidden = false;
    showError(error.message);
  }
}


el('logout').addEventListener('click', async () => {
  if (working || !authenticated) return;
  working = true;
  el('logout').textContent = 'Signing out…';
  try {
    await send({ type: 'auth:logout' });
    authenticated = false;
    hasExistingAccount = false;
    el('existing').hidden = true;
    el('new').hidden = false;
    setAuthenticated(false);
    showError('Signed out on this device. Your cloud account and paper data were not deleted. Enter your license key to sign in again.');
  } catch (error) { showError(error.message); }
  finally { working = false; el('logout').textContent = 'Sign out on this device'; updateButton(); }
});

el('delete-account').addEventListener('click', async () => {
  if (working || !authenticated) return;
  const confirmed = confirm('Permanently delete your VirtualSol cloud account, all paper wallets, trades, history and every license linked to this account? This cannot be undone.');
  if (!confirmed) return;
  working = true;
  el('delete-account').textContent = 'Deleting account…';
  try {
    await send({ type: 'auth:delete-account' });
    authenticated = false;
    hasExistingAccount = false;
    el('existing').hidden = true;
    el('new').hidden = true;
    setAuthenticated(false);
    el('license-section').hidden = true;
    el('go').hidden = true;
    el('status').textContent = 'Your cloud account, paper data, sessions and linked licenses have been permanently deleted.';
    el('status').hidden = false;
    el('account-actions').hidden = true;
  } catch (error) { showError(error.message); }
  finally { working = false; el('delete-account').textContent = 'Delete account and paper data'; updateButton(); }
});

el('go').addEventListener('click', async () => {
  if (working) return;
  const startingSol = hasExistingAccount ? '100' : validStartingAmount();
  if (!startingSol) return;
  working = true;
  el('go').disabled = true;
  el('go').textContent = 'Connecting…';
  el('status').hidden = true;
  el('steps').hidden = false;
  for (const name of ['account','mode','guard','open']) document.querySelector(`#steps li[data-k="${name}"]`).removeAttribute('data-s');

  try {
    if (!authenticated) {
      setStep('account','run');
      const licenseKey = el('license').value.replace(/\s+/g, '').toUpperCase();
      await send({ type: 'auth:activate', licenseKey });
      authenticated = true;
      setAuthenticated(true);
    }

    setStep('account','run');
    const result = await send({ type: 'popup:activate', startingSol });
    setStep('account','ok');
    setStep('mode', result.mode === 'SIM_ON' ? 'ok' : 'bad');
    setStep('guard', result.guard ? 'ok' : 'bad');
    if (!result.active) throw new Error('Paper trading could not be confirmed active. Axiom was not opened. Reload the extension and try again.');
    setStep('open','run');
    el('go').textContent = result.reused ? `Continuing with ${fmt(result.mainSol)} SOL` : `Ready · ${fmt(result.mainSol)} SOL`;
    setTimeout(() => location.assign('https://axiom.trade/pulse'), 450);
  } catch (error) {
    setStep('account','bad');
    showError(error.message);
  } finally {
    working = false;
    updateButton();
  }
});

boot();
